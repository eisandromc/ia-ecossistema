/* Regras do simulador. Valores monetários são inteiros em centavos. */
((root) => {
  "use strict";
  const STATUS = {
    draft: "Rascunho", review: "Em aprovação", approved: "Aprovado", issued: "Emitido",
    partial: "Recebido parcial", received: "Recebido", rejected: "Reprovado", cancelled: "Cancelado"
  };
  const ACTORS = {
    ana: { name: "Ana Ribeiro", role: "Compras" },
    paulo: { name: "Paulo Mendes", role: "Gerência" },
    elisa: { name: "Elisa Torres", role: "Diretoria" },
    bia: { name: "Beatriz Lima", role: "Estoque" }
  };
  const TYPES = ["clients", "categories", "sellers", "suppliers", "products"];
  const TERMS = ["À vista", "15 dias", "30 dias", "45 dias", "60 dias"];
  const COMMITTED = new Set(["review", "approved", "issued", "partial", "received"]);
  const DAY = /^\d{4}-\d{2}-\d{2}$/;
  const moneyLimit = 1000000000;
  const clean = (v) => String(v ?? "").trim();
  const copy = (value) => JSON.parse(JSON.stringify(value));
  const person = (actor) => ACTORS[actor]?.name ?? "Simulador";
  function check(condition, message) { if (!condition) throw new Error(message); }
  function integer(v, min, max, label) {
    check(typeof v === "number" && Number.isSafeInteger(v) && v >= min && v <= max, `${label} deve estar entre ${min} e ${max}.`);
    return v;
  }
  function label(v, name, max = 120, required = true) {
    const value = clean(v);
    check((!required || value.length > 0) && value.length <= max, `${name} ${required ? "é obrigatório e " : ""}deve ter até ${max} caracteres.`);
    return value;
  }
  function validDate(v) {
    if (!DAY.test(v)) return false;
    const date = new Date(v + "T00:00:00Z");
    return !Number.isNaN(date.valueOf()) && date.toISOString().slice(0, 10) === v;
  }
  function today() {
    const now = new Date();
    return new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  }
  function find(state, kind, id) { return state[kind].find((row) => row.id === id); }
  function requireRow(state, kind, id) {
    const row = find(state, kind, id);
    check(row, "Registro não encontrado.");
    return row;
  }
  function active(state, kind, id, name) {
    const row = requireRow(state, kind, id);
    check(row.active, `${name} está inativo: ${row.name}.`);
    return row;
  }
  function code(state, prefix) {
    state.seq++;
    return `${prefix}-${String(state.seq).padStart(4, "0")}`;
  }
  function record(state, actor, action, ref, detail = "") {
    state.audit.unshift({ at: new Date().toISOString(), actor: person(actor), action, ref, detail });
  }
  function role(actor, expected) {
    check(ACTORS[actor]?.role === expected, `Troque para o perfil ${expected} para realizar esta ação.`);
  }
  function percentage(cents, basisPoints) { return Math.round(cents * basisPoints / 10000); }

  const DEFAULTS = {
    minOrder: 10000, approval1: 500000, approval2: 2000000, maxDiscount: 1500,
    quoteFrom: 1000000, minQuotes: 2, requireCenter: true, allowOverBudget: false,
    payment: "30 dias", tax: 0, centers: ["Setor Implantação", "Setor Comercial", "Setor Tecnologia", "Setor Operações"]
  };
  function blank() {
    return { version: 1, seq: 0, settings: copy(DEFAULTS), clients: [], categories: [], sellers: [],
      suppliers: [], products: [], orders: [], inventory: [], audit: [] };
  }
  function normalizeSettings(input) {
    const result = {};
    for (const key of ["minOrder", "approval1", "approval2", "quoteFrom"]) result[key] = integer(input[key], 0, moneyLimit, key);
    check(result.approval2 > result.approval1, "A alçada da diretoria precisa ser maior que a alçada da gerência.");
    result.maxDiscount = integer(input.maxDiscount, 0, 10000, "Limite de desconto");
    result.tax = integer(input.tax, 0, 10000, "Taxa simulada");
    result.minQuotes = integer(input.minQuotes, 1, 5, "Cotações mínimas");
    check(TERMS.includes(input.payment), "Condição de pagamento inválida.");
    check(typeof input.requireCenter === "boolean" && typeof input.allowOverBudget === "boolean", "Parâmetros de controle inválidos.");
    result.payment = input.payment;
    result.requireCenter = input.requireCenter;
    result.allowOverBudget = input.allowOverBudget;
    check(Array.isArray(input.centers) && input.centers.length <= 40, "Cadastre até 40 centros de custo.");
    result.centers = input.centers.map((value) => label(value, "Centro de custo", 80));
    check(new Set(result.centers.map((v) => v.toLocaleLowerCase("pt-BR"))).size === result.centers.length, "Centros de custo duplicados.");
    check(!result.requireCenter || result.centers.length, "Cadastre ao menos um centro de custo obrigatório.");
    return result;
  }
  function saveSettings(state, input, actor) {
    role(actor, "Compras");
    state.settings = normalizeSettings(input);
    record(state, actor, "Atualizou parâmetros", "Regras de compra");
  }
  function normalizeRecord(state, kind, input, id) {
    check(TYPES.includes(kind), "Tipo de cadastro inválido.");
    check(typeof input.active === "boolean", "Situação do cadastro inválida.");
    const row = { name: label(input.name, "Nome"), active: input.active };
    if (["clients", "sellers", "suppliers"].includes(kind)) {
      row.email = label(input.email, "E-mail", 160, false);
      check(!row.email || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.email), "Informe um e-mail válido.");
    }
    if (kind === "clients") {
      row.budget = integer(input.budget, 0, moneyLimit, "Orçamento mensal em centavos");
      row.segment = label(input.segment, "Segmento", 80, false);
    }
    if (kind === "sellers") row.team = label(input.team, "Equipe", 80, false);
    if (kind === "suppliers") {
      row.lead = integer(input.lead, 0, 365, "Prazo padrão em dias");
      row.contact = label(input.contact, "Contato", 100, false);
    }
    if (kind === "categories") {
      row.description = label(input.description, "Descrição", 240, false);
      row.level = integer(input.level, 0, 2, "Nível de aprovação");
    }
    if (kind === "products") {
      row.sku = label(input.sku, "SKU", 36).toUpperCase();
      check(!state.products.some((x) => x.id !== id && x.sku === row.sku), "Já existe um produto com esse SKU.");
      const category = requireRow(state, "categories", input.categoryId);
      row.categoryId = category.id;
      row.price = integer(input.price, 1, moneyLimit, "Custo unitário em centavos");
      check(["stock", "service"].includes(input.type), "Tipo de produto inválido.");
      row.type = input.type;
      row.minStock = row.type === "stock" ? integer(input.minStock, 0, 1000000, "Estoque mínimo") : 0;
    }
    return row;
  }
  function saveRecord(state, kind, input, actor, id) {
    role(actor, "Compras");
    const old = id ? requireRow(state, kind, id) : null;
    const row = normalizeRecord(state, kind, input, id);
    if (kind === "products" && old && old.type !== row.type) {
      check(!state.inventory.some((event) => event.productId === id) &&
        !state.orders.some((order) => order.lines.some((line) => line.productId === id)),
      "O tipo de um produto com movimentações ou pedidos deve ser mantido.");
    }
    row.id = old?.id ?? code(state, { clients: "CLI", categories: "CAT", sellers: "VEN", suppliers: "FOR", products: "PRO" }[kind]);
    if (old) Object.assign(old, row);
    else state[kind].push(row);
    record(state, actor, old ? "Editou cadastro" : "Criou cadastro", row.id, row.name);
    return old ?? row;
  }
  function lineTotals(line, taxRate = 0) {
    const gross = line.qty * line.price;
    const discount = percentage(gross, line.discount);
    const net = gross - discount;
    const tax = percentage(net, taxRate);
    return { gross, discount, net, tax, total: net + tax };
  }
  function totals(order) {
    const sum = { gross: 0, discount: 0, net: 0, tax: 0, total: 0 };
    for (const line of order.lines) {
      const row = lineTotals(line, order.tax);
      for (const field of Object.keys(sum)) sum[field] += row[field];
    }
    return { ...sum, freight: order.freight, total: sum.total + order.freight };
  }
  function normalizeOrder(state, input, id) {
    check(validDate(input.date) && validDate(input.due) && input.due >= input.date, "Informe datas válidas. A entrega deve ocorrer na data do pedido ou depois.");
    check(TERMS.includes(input.payment), "Condição de pagamento inválida.");
    const client = active(state, "clients", input.clientId, "Cliente");
    const supplier = active(state, "suppliers", input.supplierId, "Fornecedor");
    const seller = active(state, "sellers", input.sellerId, "Vendedor");
    check(Array.isArray(input.lines) && input.lines.length > 0 && input.lines.length <= 50, "Inclua entre 1 e 50 itens no pedido.");
    const used = new Set();
    const lines = input.lines.map((line) => {
      const product = active(state, "products", line.productId, "Produto");
      const category = active(state, "categories", product.categoryId, "Categoria");
      check(!used.has(product.id), "Consolide os produtos repetidos em uma única linha.");
      used.add(product.id);
      return {
        productId: product.id, name: product.name, sku: product.sku, type: product.type, categoryId: category.id,
        qty: integer(line.qty, 1, 100000, "Quantidade"),
        price: integer(line.price, 1, moneyLimit, "Preço unitário em centavos"),
        discount: integer(line.discount, 0, 10000, "Desconto"), received: 0
      };
    });
    check(Array.isArray(input.quotes) && input.quotes.length <= 5, "Registre até cinco cotações.");
    const sources = new Set();
    const quotes = input.quotes.map((entry) => {
      const name = label(entry.name, "Referência da cotação", 90);
      const key = name.toLocaleLowerCase("pt-BR");
      check(!sources.has(key), "As cotações precisam ter referências distintas.");
      sources.add(key);
      return { name, price: integer(entry.price, 1, moneyLimit, "Valor da cotação em centavos") };
    });
    const order = {
      id, clientId: client.id, supplierId: supplier.id, sellerId: seller.id,
      clientName: client.name, supplierName: supplier.name, sellerName: seller.name,
      date: input.date, due: input.due, center: label(input.center, "Centro de custo", 80, false),
      notes: label(input.notes, "Observações", 700, false), payment: input.payment,
      tax: state.settings.tax, freight: integer(input.freight, 0, moneyLimit, "Frete em centavos"),
      lines, quotes
    };
    check(lines.reduce((sum, line) => sum + line.qty * line.price, 0) <= moneyLimit,
      "O valor bruto dos itens excede o limite de R$ 10 milhões do simulador.");
    check(totals(order).total <= moneyLimit, "O total do pedido excede o limite de R$ 10 milhões do simulador.");
    return order;
  }
  function saveOrder(state, input, actor, id) {
    role(actor, "Compras");
    const old = id ? requireRow(state, "orders", id) : null;
    check(!old || old.status === "draft", "Apenas rascunhos podem ser editados.");
    const row = normalizeOrder(state, input, id);
    row.id = old?.id ?? code(state, "PC");
    row.status = "draft";
    row.requester = old?.requester ?? actor;
    row.created = old?.created ?? new Date().toISOString();
    row.approvals = [];
    row.route = [];
    row.reasons = [];
    if (old) Object.assign(old, row);
    else state.orders.unshift(row);
    record(state, actor, old ? "Editou rascunho" : "Criou pedido", row.id, row.clientName);
    return old ?? row;
  }
  function usedBudget(state, clientId, month, excludeId) {
    return state.orders.filter((o) => o.id !== excludeId && o.clientId === clientId && o.date.startsWith(month) && COMMITTED.has(o.status))
      .reduce((total, o) => total + totals(o).total, 0);
  }
  function review(state, input) {
    const config = state.settings;
    const order = normalizeOrder(state, input, input.id);
    const value = totals(order).total;
    const errors = [], reasons = [];
    let level = 0;
    if (value < config.minOrder) errors.push("O total está abaixo do pedido mínimo configurado.");
    if (config.requireCenter && !order.center) errors.push("Informe um centro de custo.");
    if (order.center && !config.centers.includes(order.center)) errors.push("Selecione um centro de custo atualmente habilitado.");
    if (order.lines.some((line) => line.discount > config.maxDiscount)) errors.push("Um ou mais itens ultrapassam o limite de desconto.");
    if (value >= config.quoteFrom && order.quotes.length < config.minQuotes) errors.push(`Registre ao menos ${config.minQuotes} cotações distintas para esta faixa de valor.`);
    if (value >= config.approval1) {
      level = value >= config.approval2 ? 2 : 1;
      reasons.push(level === 2 ? "Valor na alçada da diretoria" : "Valor na alçada da gerência");
    }
    for (const line of order.lines) {
      const category = requireRow(state, "categories", line.categoryId);
      if (category.level && !reasons.includes(`Categoria controlada: ${category.name}`)) {
        reasons.push(`Categoria controlada: ${category.name}`);
        level = Math.max(level, category.level);
      }
    }
    const client = requireRow(state, "clients", order.clientId);
    const committed = usedBudget(state, client.id, order.date.slice(0, 7), input.id);
    if (client.budget && committed + value > client.budget) {
      if (!config.allowOverBudget) errors.push("O pedido excede o orçamento mensal disponível do cliente.");
      else { level = 2; reasons.push("Exceção de orçamento mensal"); }
    }
    return { order, errors, reasons, route: level === 2 ? ["Gerência", "Diretoria"] : level === 1 ? ["Gerência"] : [], committed, budget: client.budget };
  }
  function transition(state, id, action, actor, note = "") {
    const order = requireRow(state, "orders", id);
    const reason = () => label(note, "Justificativa", 400);
    const save = (verb, detail = "") => record(state, actor, verb, id, detail);
    if (action === "submit") {
      role(actor, "Compras");
      check(order.status === "draft", "Somente rascunhos podem ser enviados.");
      const result = review(state, order);
      check(!result.errors.length, result.errors.join(" "));
      Object.assign(order, result.order, { status: result.route.length ? "review" : "approved",
        requester: actor, reasons: result.reasons, route: result.route, approvals: [] });
      save(result.route.length ? "Enviou para aprovação" : "Aprovação automática", result.reasons.join(" · "));
    } else if (action === "approve" || action === "reject") {
      check(order.status === "review", "O pedido não está na fila de aprovação.");
      role(actor, order.route[order.approvals.length]);
      check(order.requester !== actor && !order.approvals.some((a) => a.actor === actor), "A aprovação exige um responsável diferente.");
      if (action === "approve") {
        order.approvals.push({ actor, role: ACTORS[actor].role, at: new Date().toISOString() });
        if (order.approvals.length === order.route.length) order.status = "approved";
        save("Aprovou pedido", ACTORS[actor].role);
      } else {
        const why = reason();
        order.status = "rejected";
        save("Reprovou pedido", why);
      }
    } else if (action === "issue") {
      role(actor, "Compras");
      check(order.status === "approved", "Apenas pedidos aprovados podem ser emitidos.");
      order.status = "issued";
      save("Emitiu pedido", order.supplierName);
    } else if (action === "reopen") {
      role(actor, "Compras");
      check(order.status === "rejected", "Apenas pedidos reprovados podem ser reabertos.");
      Object.assign(order, { status: "draft", route: [], approvals: [], reasons: [] });
      save("Reabriu pedido");
    } else if (action === "cancel") {
      role(actor, "Compras");
      check(["draft", "review", "approved", "issued", "rejected"].includes(order.status), "Pedidos com recebimento ou já cancelados exigem outro tratamento.");
      const why = reason();
      order.status = "cancelled";
      save("Cancelou pedido", why);
    } else {
      throw new Error("Ação desconhecida.");
    }
    return order;
  }
  function stock(state, productId) {
    return state.inventory.filter((event) => event.productId === productId).reduce((sum, event) => sum + event.delta, 0);
  }
  function adjustment(state, productId, delta, note, actor) {
    role(actor, "Estoque");
    const product = requireRow(state, "products", productId);
    check(product.type === "stock", "Ajustes são permitidos apenas para itens estocáveis.");
    integer(delta, -1000000, 1000000, "Quantidade do ajuste");
    check(delta !== 0 && stock(state, productId) + delta >= 0, "O ajuste precisa ser diferente de zero e não pode deixar saldo negativo.");
    const why = label(note, "Motivo do ajuste", 400);
    state.inventory.unshift({ at: new Date().toISOString(), productId, delta, ref: "Ajuste", note: why });
    record(state, actor, "Ajustou estoque", product.sku, why);
  }
  function receive(state, id, quantities, note, actor) {
    role(actor, "Estoque");
    const order = requireRow(state, "orders", id);
    check(["issued", "partial"].includes(order.status), "Apenas pedidos emitidos ou parcialmente recebidos aceitam recebimento.");
    const why = label(note, "Documento ou referência do recebimento", 150);
    check(Array.isArray(quantities) && quantities.length === order.lines.length, "Quantidade de linhas inválida.");
    quantities.forEach((qty, index) => integer(qty, 0, order.lines[index].qty - order.lines[index].received, `Recebimento de ${order.lines[index].sku}`));
    check(quantities.some(Boolean), "Informe ao menos uma quantidade recebida.");
    const at = new Date().toISOString();
    order.lines.forEach((line, index) => {
      const qty = quantities[index];
      if (!qty) return;
      line.received += qty;
      if (line.type === "stock") state.inventory.unshift({ at, productId: line.productId, delta: qty, ref: id, note: why });
    });
    order.status = order.lines.every((line) => line.received === line.qty) ? "received" : "partial";
    record(state, actor, order.status === "received" ? "Concluiu recebimento" : "Recebeu parcialmente", id, why);
    return order;
  }

  function seed() {
    const state = blank();
    const clients = [
      ["Cliente Aurora Norte", "Distribuição", 9500000], ["Cliente Bravante", "Indústria", 8500000],
      ["Cliente Cobalto", "Serviços", 10000000], ["Cliente Douramar", "Atacado", 12000000],
      ["Cliente Estrela do Vale", "Educação", 6500000]
    ].map(([name, segment, budget]) => saveRecord(state, "clients", { name, segment, budget, active: true }, "ana"));
    const categories = [
      ["Equipamentos", 0, "Estações de trabalho, monitores e periféricos."],
      ["Infraestrutura", 1, "Rede, conectividade e armazenamento."],
      ["Licenças de software", 0, "Assinaturas, acessos e ferramentas digitais."],
      ["Serviços técnicos", 0, "Implantação, configuração e treinamento."]
    ].map(([name, level, description]) => saveRecord(state, "categories", { name, level, description, active: true }, "ana"));
    const sellers = [["Camila Duarte", "Contas corporativas"], ["Rafael Martins", "Operações comerciais"], ["Marina Lopes", "Projetos"]]
      .map(([name, team]) => saveRecord(state, "sellers", { name, team, active: true }, "ana"));
    const suppliers = [["Nexo Tecnologia", 5], ["Ápice Sistemas", 8], ["Vértice Suprimentos", 4], ["BaseLab Serviços", 10]]
      .map(([name, lead]) => saveRecord(state, "suppliers", { name, lead, active: true }, "ana"));
    const products = [
      ["Notebook corporativo", "EQ-010", 0, 429000, 6, 4], ["Monitor 24 polegadas", "EQ-020", 0, 89000, 5, 18],
      ["Switch gerenciável", "IN-010", 1, 179000, 4, 2], ["Unidade SSD 1 TB", "IN-020", 1, 51900, 4, 24],
      ["Licença de análise anual", "SW-010", 2, 130000, 0, 0], ["Pacote de implantação", "SV-010", 3, 650000, 0, 0],
      ["Treinamento remoto", "SV-020", 3, 165000, 0, 0], ["Kit teclado e mouse", "EQ-030", 0, 15900, 8, 26]
    ].map(([name, sku, category, price, minStock, initial]) => {
      const row = saveRecord(state, "products", { name, sku, categoryId: categories[category].id, price,
        minStock, type: category < 2 ? "stock" : "service", active: true }, "ana");
      if (initial) adjustment(state, row.id, initial, "Saldo inicial fictício", "bia");
      return row;
    });
    const localDay = (delta) => {
      const date = new Date(today() + "T12:00:00Z");
      date.setUTCDate(date.getUTCDate() + delta);
      return date.toISOString().slice(0, 10);
    };
    const examples = [
      [-125, 0, 0, [[1, 5]], "received", "Renovação das estações de atendimento."],
      [-99, 1, 1, [[5, 2]], "received", "Pacotes de implantação para duas unidades."],
      [-71, 2, 2, [[0, 4]], "received", "Equipamentos da equipe de manutenção."],
      [-42, 3, 0, [[2, 9], [3, 4]], "issued", "Ampliação da infraestrutura de rede."],
      [-25, 2, 3, [[6, 3]], "approved", "Capacitação de usuários do novo sistema."],
      [-15, 0, 1, [[4, 20]], "review", "Licenças analíticas para a expansão."],
      [-10, 1, 0, [[0, 3], [1, 4]], "partial", "Renovação de notebooks e monitores."],
      [-5, 3, 2, [[2, 3]], "review", "Rede de uma nova unidade."],
      [-2, 4, 3, [[5, 1]], "draft", "Implantação piloto com a equipe de operações."]
    ];
    for (const [offset, ci, fi, items, status, notes] of examples) {
      const order = saveOrder(state, {
        clientId: clients[ci].id, supplierId: suppliers[fi].id, sellerId: sellers[ci % sellers.length].id,
        date: localDay(offset), due: localDay(offset + 14), center: state.settings.centers[ci % 4],
        notes, payment: "30 dias", freight: 0,
        lines: items.map(([p, qty]) => ({ productId: products[p].id, qty, price: products[p].price, discount: 0 })),
        quotes: [{ name: suppliers[fi].name, price: 1800000 }, { name: "Alternativa consultada", price: 1950000 }]
      }, "ana");
      if (status === "draft") continue;
      transition(state, order.id, "submit", "ana");
      if (status === "review") continue;
      if (order.status === "review") transition(state, order.id, "approve", "paulo");
      if (order.status === "review") transition(state, order.id, "approve", "elisa");
      if (status === "approved") continue;
      transition(state, order.id, "issue", "ana");
      if (status === "issued") continue;
      receive(state, order.id, order.lines.map((line, i) => status === "received" ? line.qty : (i === 0 ? 1 : 0)), "Comprovante fictício", "bia");
    }
    return state;
  }

  function importBackup(payload) {
    check(payload && payload.version === 1, "Formato ou versão de backup incompatível.");
    const state = copy(payload);
    integer(state.seq, 0, 100000000, "Sequência de registros");
    state.settings = normalizeSettings(state.settings ?? {});
    const ids = new Set();
    for (const kind of [...TYPES, "orders", "inventory", "audit"]) {
      check(Array.isArray(state[kind]) && state[kind].length <= 10000, `Lista inválida no backup: ${kind}.`);
    }
    for (const kind of [...TYPES, "orders"]) {
      for (const row of state[kind]) {
        check(row && typeof row.id === "string" && /^[A-Z]{2,4}-\d{4,9}$/.test(row.id) && !ids.has(row.id) &&
          Number(row.id.split("-")[1]) <= state.seq, "IDs duplicados ou inválidos no backup.");
        ids.add(row.id);
        if (kind !== "orders") normalizeRecord(state, kind, row, row.id);
      }
    }
    for (const order of state.orders) {
      check(Object.hasOwn(STATUS, order.status) && ACTORS[order.requester] && validDate(order.date) && validDate(order.due) &&
        order.due >= order.date && TERMS.includes(order.payment), "Pedido inválido no backup.");
      for (const [kind, key] of [["clients", "clientId"], ["suppliers", "supplierId"], ["sellers", "sellerId"]]) requireRow(state, kind, order[key]);
      for (const key of ["clientName", "supplierName", "sellerName"]) label(order[key], key);
      integer(order.tax, 0, 10000, "Taxa");
      integer(order.freight, 0, moneyLimit, "Frete");
      check(Array.isArray(order.lines) && order.lines.length && order.lines.length <= 50 &&
        Array.isArray(order.quotes) && order.quotes.length <= 5 && Array.isArray(order.route) &&
        Array.isArray(order.reasons) && Array.isArray(order.approvals), "Estrutura de pedido inválida.");
      const lineIds = new Set();
      for (const line of order.lines) {
        const product = requireRow(state, "products", line.productId);
        check(product.type === line.type && !lineIds.has(line.productId), "Produto de pedido inválido ou duplicado.");
        lineIds.add(line.productId);
        label(line.name, "Produto");
        label(line.sku, "SKU", 36);
        integer(line.qty, 1, 100000, "Quantidade");
        integer(line.price, 1, moneyLimit, "Preço");
        integer(line.discount, 0, 10000, "Desconto");
        integer(line.received, 0, line.qty, "Recebimento");
      }
      check(order.lines.reduce((sum, line) => sum + line.qty * line.price, 0) <= moneyLimit &&
        totals(order).total <= moneyLimit, "Valor do pedido fora do limite do simulador.");
      for (const quote of order.quotes) {
        label(quote.name, "Cotação", 90);
        integer(quote.price, 1, moneyLimit, "Valor da cotação");
      }
      check(JSON.stringify(order.route) === "[]" || JSON.stringify(order.route) === '["Gerência"]' ||
        JSON.stringify(order.route) === '["Gerência","Diretoria"]', "Alçada inválida no backup.");
      check(order.approvals.length <= order.route.length && order.approvals.every((approval, i) => approval &&
        ACTORS[approval.actor]?.role === order.route[i] && approval.role === order.route[i] && approval.actor !== order.requester),
        "Aprovações inválidas no backup.");
      check(order.status !== "review" || order.approvals.length < order.route.length, "Fila de aprovação inválida no backup.");
      check(!["approved", "issued", "partial", "received"].includes(order.status) ||
        order.approvals.length === order.route.length, "Pedido avançou sem concluir as alçadas.");
      const has = order.lines.some((line) => line.received > 0);
      const complete = order.lines.every((line) => line.received === line.qty);
      check(order.status === "received" ? complete : order.status === "partial" ? has && !complete : !has, "Recebimento incompatível com a situação do pedido.");
    }
    const balances = new Map(), linked = new Map();
    for (const event of [...state.inventory].reverse()) {
      const product = requireRow(state, "products", event.productId);
      check(product.type === "stock", "Movimentação de item não estocável.");
      integer(event.delta, -1000000, 1000000, "Movimentação");
      check(event.delta !== 0, "Movimentação sem quantidade.");
      const balance = (balances.get(product.id) ?? 0) + event.delta;
      check(balance >= 0, "Saldo negativo no histórico de estoque.");
      balances.set(product.id, balance);
      if (event.ref !== "Ajuste") {
        const order = requireRow(state, "orders", event.ref);
        check(event.delta > 0 && order.lines.some((line) => line.productId === product.id), "Movimentação vinculada inválida.");
        const key = order.id + "/" + product.id;
        linked.set(key, (linked.get(key) ?? 0) + event.delta);
      }
    }
    for (const order of state.orders) for (const line of order.lines) {
      if (line.type === "stock") check((linked.get(order.id + "/" + line.productId) ?? 0) === line.received, "Pedido e estoque não conciliados.");
    }
    check(state.audit.every((row) => row && ["at", "actor", "action", "ref", "detail"].every((key) => typeof row[key] === "string")),
      "Histórico de auditoria inválido.");
    return state;
  }

  const api = { STATUS, ACTORS, TERMS, TYPES, COMMITTED, DEFAULTS, blank, seed, copy, today, find, totals, lineTotals,
    saveSettings, saveRecord, saveOrder, review, transition, usedBudget, stock, adjustment, receive, importBackup };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.PurchaseEngine = api;
})(globalThis);
