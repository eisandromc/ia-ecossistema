(() => {
  "use strict";
  const E = globalThis.PurchaseEngine;
  const $ = (s, node = document) => node.querySelector(s);
  const $$ = (s, node = document) => [...node.querySelectorAll(s)];
  const key = "nexo.compras.v1";
  const currency = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
  const num = new Intl.NumberFormat("pt-BR");
  const brDate = new Intl.DateTimeFormat("pt-BR", { timeZone: "UTC" });
  const brTime = new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" });
  const escape = (value) => String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
  const money = (value) => currency.format(value / 100);
  const date = (value) => value ? brDate.format(new Date(value + "T00:00:00Z")) : "—";
  const stamp = (v) => Number.isFinite(Date.parse(v)) ? brTime.format(new Date(v)) : "—";
  const units = (value) => num.format(value);
  const pct = (value) => num.format(value / 100) + "%";
  const normal = (value) => String(value ?? "").normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase();
  const matches = (q, ...values) => values.some((value) => normal(value).includes(normal(q)));
  const inputMoney = (value) => (value / 100).toFixed(2);
  const cents = (value) => {
    const raw = String(value ?? "").trim();
    if (!raw) return 0;
    if (!/^\d+(?:[.,]\d{1,2})?$/.test(raw)) return NaN;
    return Math.round(Number(raw.replace(",", ".")) * 100);
  };
  const valueOf = (form, name) => form.elements.namedItem(name)?.value ?? "";
  const flag = (form, name) => Boolean(form.elements.namedItem(name)?.checked);
  const dateOffset = (day, offset) => {
    if (!day || !/^\d{4}-\d{2}-\d{2}$/.test(day)) return "";
    const dt = new Date(day + "T12:00:00Z");
    dt.setUTCDate(dt.getUTCDate() + offset);
    return dt.toISOString().slice(0, 10);
  };
  const paths = {
    brand: '<path d="M3 7h15l2 4-2 7H6L3 7Z"/><path d="m8 7 3-4 3 4m-5 5h6"/>',
    home: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    order: '<path d="M6 3h9l4 4v14H6zM14 3v5h5M9 12h7m-7 4h7"/>',
    users: '<circle cx="9" cy="7" r="3"/><path d="M3 20v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2m1-16a3 3 0 0 1 0 6m2 4a4 4 0 0 1 3 4v2"/>',
    user: '<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a5 5 0 0 1 5-5h6a5 5 0 0 1 5 5v2"/>',
    tag: '<path d="M3 3h8l10 10-8 8L3 11z"/><circle cx="7.5" cy="7.5" r="1"/>',
    cube: '<path d="m12 3 9 5v8l-9 5-9-5V8zm0 10 9-5m-9 5L3 8m9 5v8"/>',
    truck: '<path d="M3 5h12v11H3zM15 9h4l2 3v4h-6"/><circle cx="7" cy="17" r="2"/><circle cx="18" cy="17" r="2"/>',
    stock: '<path d="m3 8 9-5 9 5v12H3zM7 12h10v8M7 16h10"/>',
    report: '<path d="M3 4v16h18M8 15v-4m5 4V6m5 9v-7"/>',
    settings: '<path d="M4 6h16M4 12h16M4 18h16M8 4v4m8 2v4m-6 2v4"/>',
    audit: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
    check: '<path d="m4 12 5 5L20 6"/>',
    wallet: '<path d="M3 5h17v14H3zm17 5h-5v4h5m-2-2h.01"/>',
    arrow: '<path d="M4 12h15m-6-6 6 6-6 6"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    close: '<path d="m6 6 12 12M6 18 18 6"/>',
    download: '<path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4"/>',
    warn: '<path d="M12 3 2 20h20zM12 9v4m0 3h.01"/>',
    pencil: '<path d="m4 16 11-11 4 4L8 20H4zm9-9 4 4"/>'
  };
  const icon = (name) => `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] ?? ""}</svg>`;
  const button = (name, label, style = "", image = "", extra = "") =>
    `<button type="button" class="btn ${style}" data-action="${name}" ${extra}>${image ? icon(image) : ""}${escape(label)}</button>`;
  const option = (value, label, selected) => `<option value="${escape(value)}"${value === selected ? " selected" : ""}>${escape(label)}</option>`;
  const field = (title, input, help = "", wide = false) =>
    `<label class="field${wide ? " wide" : ""}">${escape(title)}${input}${help ? `<small class="hint">${escape(help)}</small>` : ""}</label>`;
  const textField = (name, value = "", attrs = "") => `<input name="${name}" value="${escape(value)}" ${attrs}>`;
  const select = (name, values, current, empty = "") => `<select name="${name}">${empty ? option("", empty, current) : ""}${values.map(([id, v]) => option(id, v, current)).join("")}</select>`;
  const badge = (status, label = E.STATUS[status]) => `<span class="badge ${escape(status)}">${escape(label)}</span>`;
  const catalog = {
    clients: { title: "Clientes", one: "cliente", icon: "users", info: "Empresas atendidas e seus limites mensais de compra." },
    categories: { title: "Categorias", one: "categoria", icon: "tag", info: "Classificação dos produtos e exigência de aprovação por categoria." },
    sellers: { title: "Vendedores", one: "vendedor", icon: "user", info: "Responsáveis comerciais associados aos pedidos." },
    suppliers: { title: "Fornecedores", one: "fornecedor", icon: "truck", info: "Parceiros de fornecimento, contatos e prazos de entrega." },
    products: { title: "Produtos", one: "produto", icon: "cube", info: "Itens estocáveis e serviços com custo de referência e classificação." }
  };
  const pages = { home: "Visão geral", orders: "Pedidos de compra", ...Object.fromEntries(Object.entries(catalog).map(([k, v]) => [k, v.title])),
    stock: "Estoque", reports: "Relatórios", settings: "Parâmetros", audit: "Auditoria" };
  let storage = true;
  let loadIssue = "";
  let state;
  let actor = "ana";
  let view = "home";
  let timer;
  let priorFocus;
  let pendingBackup;
  const filters = { home: "all", orders: "", orderStatus: "", orderClient: "", list: {}, inventory: "", audit: "", month: "", reportClient: "" };
  try {
    localStorage.setItem(key + ".probe", "1");
    localStorage.removeItem(key + ".probe");
  } catch { storage = false; }
  try {
    state = storage && localStorage.getItem(key) ? E.importBackup(JSON.parse(localStorage.getItem(key))) : E.seed();
  } catch {
    state = E.seed();
    loadIssue = "O conteúdo salvo estava inválido. A demonstração foi carregada. Exporte ou importe um backup em Parâmetros.";
  }
  function commit(change) {
    const saved = storage && !loadIssue ? localStorage.getItem(key) : null;
    const draft = saved ? JSON.parse(saved) : E.copy(state);
    const result = change(draft);
    if (storage) localStorage.setItem(key, JSON.stringify(draft));
    state = draft;
    loadIssue = "";
    return result;
  }
  function replaceState(next) {
    if (storage) localStorage.setItem(key, JSON.stringify(next));
    state = next;
    loadIssue = "";
  }
  const currentRole = () => E.ACTORS[actor].role;
  const canBuy = () => currentRole() === "Compras";
  const lookup = (kind, id) => E.find(state, kind, id);
  function toast(message) {
    const node = $("#toast");
    node.textContent = message;
    clearTimeout(timer);
    timer = setTimeout(() => { node.textContent = ""; }, 4200);
  }
  function notice(text, kind = "", trailing = "") {
    return `<div class="notice ${kind}">${icon(kind ? "warn" : "check")}<span>${escape(text)}</span>${trailing}</div>`;
  }
  function table(headers, rows, empty = "Nenhum registro encontrado.") {
    return `<div class="table-scroll" tabindex="0" aria-label="Tabela com rolagem horizontal"><table><thead><tr>${headers.map((h) =>
      `<th scope="col"${h.startsWith("R$ ") ? ' class="amount"' : ""}>${escape(h.replace(/^R\$ /, ""))}</th>`).join("")}</tr></thead><tbody>${rows.length ?
      rows.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join("")}</tr>`).join("") :
      `<tr><td colspan="${headers.length}" class="empty"><strong>${escape(empty)}</strong></td></tr>`}</tbody></table></div>`;
  }
  function heading(title, info, actions = "", overline = "Gestão de compras") {
    return `<div class="page-head"><div><p class="eyebrow">${escape(overline)}</p><h1>${escape(title)}</h1>
      <p class="subtitle">${escape(info)}</p></div>${actions ? `<div class="actions">${actions}</div>` : ""}</div>`;
  }
  const panelHead = (title, subtitle = "", extra = "") =>
    `<div class="panel-head"><div><h2>${escape(title)}</h2>${subtitle ? `<p class="subtitle">${escape(subtitle)}</p>` : ""}</div>${extra}</div>`;
  const actionOrder = (id) => `data-id="${escape(id)}"`;
  const plus = (action, title, attrs = "") => button(action, title, "primary", "plus", attrs);
  const amount = (n) => `<div class="amount">${money(n)}</div>`;
  const orderLink = (o) => `<button type="button" class="text-link nowrap" data-action="order-detail" ${actionOrder(o.id)}>${escape(o.id)}</button>`;
  const sumOrders = (orders) => orders.reduce((sum, order) => sum + E.totals(order).total, 0);
  const datedOpen = (o) => ["issued", "partial"].includes(o.status) && o.due < E.today();
  const roleName = () => E.ACTORS[actor].name;
  const hashPage = () => {
    const slug = location.hash.slice(1);
    return Object.hasOwn(pages, slug) ? slug : "home";
  };
  function go(name) {
    if (!Object.hasOwn(pages, name)) return;
    view = name;
    if (location.hash !== "#" + name) history.pushState(null, "", "#" + name);
    closeDialog();
    render();
    $("#content").focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }
  function shell() {
    const queue = state.orders.filter((o) => o.status === "review").length;
    const groups = [["Operação", [["home", "home"], ["orders", "order"], ["stock", "stock"], ["reports", "report"]]],
      ["Cadastros", [["clients", "users"], ["categories", "tag"], ["products", "cube"], ["sellers", "user"], ["suppliers", "truck"]]],
      ["Administração", [["settings", "settings"], ["audit", "audit"]]]];
    $("#sidebar").classList.remove("open");
    $("#sidebar").innerHTML = `${button("menu", "", "mobile-menu icon-btn", "close", 'aria-label="Fechar menu"')}
      <button class="brand" type="button" data-go="home"><span class="brand-mark">${icon("brand")}</span><span><strong>Nexo Compras</strong><small>Gestão de suprimentos</small></span></button>
      <nav aria-label="Seções do simulador">${groups.map(([label, items]) => `<div class="nav-group"><p class="nav-label">${label}</p>${items.map(([id, image]) =>
        `<button type="button" class="nav-link" data-go="${id}"${view === id ? ' aria-current="page"' : ""}>${icon(image)}${pages[id]}
         ${id === "orders" && queue ? `<span class="nav-count" title="Pedidos em aprovação">${queue}</span>` : ""}</button>`).join("")}</div>`).join("")}</nav>
      <div class="sidebar-foot"><strong>Ambiente de simulação</strong>${storage ? "Dados neste navegador" : "Dados temporários"}</div>`;
    $("#topbar").innerHTML = `<div class="top-group">
      ${button("menu", "", "mobile-menu icon-btn", "menu", 'aria-label="Abrir menu" aria-expanded="false" aria-controls="sidebar"')}
      <div class="breadcrumb"><span>Compras &nbsp;/&nbsp; </span><strong>${pages[view]}</strong></div></div>
      <div class="top-group"><button type="button" class="search-button" data-action="search" aria-label="Busca global">${icon("search")}<span>Buscar registros</span><kbd>Ctrl K</kbd></button>
      <label class="profile"><span class="avatar" aria-hidden="true">${roleName().split(" ").slice(0, 2).map((s) => s[0]).join("")}</span>
        <select id="actor" aria-label="Perfil de simulação" title="${escape(roleName())}">${Object.entries(E.ACTORS).map(([id, a]) => option(id, a.role, actor)).join("")}</select>
      </label></div>`;
  }
  function metric(label, val, help, image) {
    return `<div class="metric"><span class="metric-top"><span class="metric-icon">${icon(image)}</span>${escape(label)}</span>
      <strong class="metric-value">${escape(val)}</strong><small>${escape(help)}</small></div>`;
  }
  function dashboard() {
    const now = E.today();
    const selection = state.orders.filter((o) => filters.home === "all" || (filters.home === "month" ?
      o.date.slice(0, 7) === now.slice(0, 7) : o.date >= dateOffset(now, -90) && o.date <= now));
    const pending = selection.filter((o) => o.status === "review");
    const open = selection.filter((o) => ["issued", "partial"].includes(o.status));
    const late = open.filter(datedOpen);
    const low = state.products.filter((p) => p.active && p.type === "stock" && E.stock(state, p.id) < p.minStock);
    const months = Array.from({ length: 6 }, (_, i) => {
      const [year, month] = now.split("-").map(Number);
      const d = new Date(Date.UTC(year, month - 6 + i, 1));
      const token = d.toISOString().slice(0, 7);
      return { name: new Intl.DateTimeFormat("pt-BR", { month: "short", timeZone: "UTC" }).format(d).replace(".", ""),
        value: sumOrders(selection.filter((o) => o.date.startsWith(token) && E.COMMITTED.has(o.status))) };
    });
    const max = Math.max(1, ...months.map((m) => m.value));
    const latest = selection.slice().sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id)).slice(0, 6);
    const period = select("home", [["all", "Todo o histórico"], ["90", "Últimos 90 dias"], ["month", "Este mês"]], filters.home)
      .replace("<select", '<select id="home-period" aria-label="Período do painel"');
    return heading("Visão geral de compras", "Acompanhe pedidos, compromissos e exceções da operação.",
      period + (canBuy() ? plus("new-order", "Novo pedido") : ""), "Central de suprimentos") +
      notice("Os dados são fictícios. Troque o perfil no topo para simular aprovações e recebimentos.", "",
        `<span class="notice-end">${button("help", "Como simular", "small")}</span>`) +
      `<section class="metric-grid" aria-label="Indicadores">
        ${metric("Compras comprometidas", money(sumOrders(selection.filter((o) => E.COMMITTED.has(o.status)))), "Inclui pedidos em aprovação", "wallet")}
        ${metric("Aguardando aprovação", units(pending.length), money(sumOrders(pending)) + " na fila", "audit")}
        ${metric("Recebimentos em aberto", units(open.length), `${late.length} com entrega em atraso`, "truck")}
        ${metric("Abaixo do estoque mínimo", units(low.length), "Somente produtos estocáveis ativos", "stock")}
      </section>
      <div class="dashboard-grid">
      <section class="panel chart-panel">${panelHead("Compras por mês", "Valor comprometido nos últimos seis meses")}
      <div class="panel-body"><div class="bars">${months.map((m) => `<div class="bar-unit" title="${m.name} · ${money(m.value)}">
        <div class="bar-track" aria-hidden="true"><div class="bar" style="height:${Math.round(100 * m.value / max)}%"></div></div>
        <small><span class="sr-only">${money(m.value)} em </span>${m.name}</small></div>`).join("")}</div></div></section>
      <section class="panel">${panelHead("Fila de trabalho", "Pendências que precisam de atenção")}
      <div class="panel-body"><ul class="legend">
        <li><span class="dot warn"></span> Aguardando aprovação <strong>${pending.length}</strong></li>
        <li><span class="dot alt"></span> Emitidos sem recebimento <strong>${open.filter((o) => o.status === "issued").length}</strong></li>
        <li><span class="dot"></span> Recebidos parcialmente <strong>${open.filter((o) => o.status === "partial").length}</strong></li>
        <li><span class="dot neutral"></span> Rascunhos <strong>${selection.filter((o) => o.status === "draft").length}</strong></li>
      </ul></div></section></div>
      <section class="panel">${panelHead("Pedidos recentes", "Últimos pedidos no período selecionado",
        '<button type="button" class="btn small" data-go="orders">Ver pedidos</button>')}
      ${ordersTable(latest)}</section>`;
  }
  function ordersTable(rows) {
    return table(["Pedido", "Cliente / Fornecedor", "Data", "Situação", "R$ Total"], rows.map((o) =>
      [orderLink(o), `<strong>${escape(o.clientName)}</strong><br><span class="muted">${escape(o.supplierName)}</span>`,
        `<span class="nowrap">${date(o.date)}</span>`, badge(o.status) + (datedOpen(o) ? ` ${badge("low", "Atrasado")}` : ""),
        amount(E.totals(o).total)]), "Nenhum pedido nesse recorte.");
  }
  function filteredOrders() {
    return state.orders.filter((o) => (!filters.orderStatus || o.status === filters.orderStatus) &&
      (!filters.orderClient || o.clientId === filters.orderClient) &&
      matches(filters.orders, o.id, o.clientName, o.supplierName, o.center, o.sellerName));
  }
  function ordersPage() {
    return heading("Pedidos de compra", "Gerencie a compra do rascunho ao recebimento.", canBuy() ? plus("new-order", "Novo pedido") : "") +
      `<section class="panel"><div class="toolbar">
      ${textField("orderSearch", filters.orders, 'id="order-search" type="search" aria-label="Buscar pedidos" placeholder="Buscar pedido, cliente ou fornecedor"')}
      <div class="actions filters">
      ${select("status", Object.entries(E.STATUS), filters.orderStatus, "Todas as situações").replace("<select", '<select id="order-status" aria-label="Situação do pedido"')}
      ${select("client", state.clients.map((c) => [c.id, c.name]), filters.orderClient, "Todos os clientes").replace("<select", '<select id="order-client" aria-label="Cliente do pedido"')}
      </div></div><div id="order-rows">${ordersTable(filteredOrders())}</div></section>`;
  }
  function catalogTable(kind) {
    const rows = state[kind].filter((row) => matches(filters.list[kind] ?? "", row.name, row.id, row.sku, row.email));
    const columns = {
      clients: [["Segmento", (r) => escape(r.segment || "—")], ["R$ Orçamento mensal", (r) => r.budget ? amount(r.budget) : "Sem teto"]],
      categories: [["Descrição", (r) => escape(r.description || "—")], ["Alçada", (r) => ["Padrão", "Gerência", "Gerência e diretoria"][r.level]]],
      products: [["SKU / categoria", (r) => `${escape(r.sku)}<br><small>${escape(lookup("categories", r.categoryId)?.name)}</small>`],
        ["Tipo", (r) => r.type === "stock" ? "Estocável" : "Serviço"], ["R$ Custo unitário", (r) => amount(r.price)]],
      sellers: [["Equipe", (r) => escape(r.team || "—")], ["E-mail", (r) => escape(r.email || "—")]],
      suppliers: [["Prazo padrão", (r) => `${r.lead} dias`], ["Contato", (r) => escape(r.contact || r.email || "—")]]
    }[kind];
    return table(["Nome", ...columns.map(([title]) => title), "Situação", ...(canBuy() ? ["Ação"] : [])], rows.map((r) =>
      [`<strong>${escape(r.name)}</strong><br><small class="muted">${r.id}</small>`, ...columns.map(([, f]) => f(r)),
        badge(r.active ? "active" : "draft", r.active ? "Ativo" : "Inativo"), ...(canBuy() ?
        [button("edit-record", "Editar", "small", "pencil", `data-kind="${kind}" data-id="${r.id}" aria-label="Editar ${escape(r.name)}"`)] : [])]));
  }
  function catalogPage(kind) {
    const info = catalog[kind];
    return heading(info.title, info.info, canBuy() ?
      plus("new-record", "Cadastrar " + info.one, `data-kind="${kind}"`) : "", "Cadastros") +
      `<section class="panel"><div class="toolbar">${textField("search", filters.list[kind], 'type="search" id="catalog-search" aria-label="Buscar no cadastro" placeholder="Buscar por nome, código ou e-mail"')}</div>
        <div id="catalog-rows">${catalogTable(kind)}</div></section>`;
  }
  function inventoryTable() {
    const rows = state.products.filter((p) => p.type === "stock" && matches(filters.inventory, p.name, p.sku));
    return table(["Produto", "SKU", "Saldo atual", "Estoque mínimo", "Situação", ...(currentRole() === "Estoque" ? ["Ação"] : [])],
      rows.map((p) => {
        const balance = E.stock(state, p.id);
        return [`<strong>${escape(p.name)}</strong>`, escape(p.sku), units(balance), units(p.minStock),
          !p.active ? badge("draft", "Inativo") : balance < p.minStock ? badge("low", "Abaixo do mínimo") : badge("active", "Adequado"),
          ...(currentRole() === "Estoque" ? [button("adjust", "Ajustar", "small", "pencil", actionOrder(p.id))] : [])];
      }));
  }
  function stockPage() {
    return heading("Estoque", "Consulte saldos, receba pedidos emitidos e registre ajustes justificados.") +
      `<section class="panel"><div class="toolbar">${textField("inventory", filters.inventory, 'id="inventory-search" type="search" aria-label="Buscar produtos no estoque" placeholder="Buscar produto ou SKU"')}
        <button class="btn" type="button" data-go="orders">Abrir pedidos</button></div><div id="inventory-rows">${inventoryTable()}</div></section>
      <section class="panel separated">${panelHead("Movimentações recentes", "O recebimento de serviços fica registrado no pedido.")}
      ${table(["Data", "Produto", "Movimento", "Origem", "Referência"], state.inventory.slice(0, 25).map((e) =>
        [stamp(e.at), escape(lookup("products", e.productId)?.name), `${e.delta > 0 ? "+" : ""}${units(e.delta)}`,
          escape(e.ref), escape(e.note)]))}</section>`;
  }
  function reportRows() {
    return state.orders.filter((o) => (!filters.month || o.date.startsWith(filters.month)) &&
      (!filters.reportClient || o.clientId === filters.reportClient));
  }
  function reportsPage() {
    const rows = reportRows();
    const committed = rows.filter((o) => E.COMMITTED.has(o.status));
    const received = committed.reduce((sum, o) => sum + o.lines.reduce((s, l) => s + l.received, 0), 0);
    const month = filters.month || E.today().slice(0, 7);
    const clients = state.clients.filter((c) => !filters.reportClient || c.id === filters.reportClient);
    const rowsByClient = clients.map((c) => {
      const value = E.usedBudget(state, c.id, month);
      return [escape(c.name), c.budget ? amount(c.budget) : "Sem teto", amount(value), c.budget ? amount(c.budget - value) : "—"];
    });
    return heading("Relatórios", "Compare compromissos por cliente e baixe os pedidos do recorte.",
      button("export-csv", "Exportar pedidos CSV", "primary", "download"), "Análise de compras") +
      `<div class="actions filters separated filter-line">${field("Mês do pedido", textField("month", filters.month, 'type="month" id="report-month"'))}
        ${field("Cliente", select("reportClient", state.clients.map((c) => [c.id, c.name]), filters.reportClient, "Todos os clientes")
          .replace("<select", '<select id="report-client"'))}</div>
      <section class="metric-grid" aria-label="Indicadores de relatório">
      ${metric("Pedidos do recorte", units(rows.length), "Inclui rascunhos e cancelados", "order")}
      ${metric("Compromissos", money(sumOrders(committed)), "Considera a fila de aprovação", "wallet")}
      ${metric("Pedidos recebidos", units(rows.filter((o) => o.status === "received").length), "Com todas as linhas recebidas", "truck")}
      ${metric("Unidades recebidas", units(received), "Inclui entregas de serviços", "cube")}</section>
      <section class="panel">${panelHead("Orçamento mensal por cliente", `Competência ${month.split("-").reverse().join("/")}`)}
      ${table(["Cliente", "R$ Orçamento", "R$ Comprometido", "R$ Disponível"], rowsByClient)}</section>
      <section class="panel separated">${panelHead("Pedidos do recorte", "O arquivo CSV inclui situação, centro de custo e total.")}${ordersTable(rows)}</section>`;
  }
  function auditTable() {
    return table(["Data e hora", "Responsável", "Ação", "Registro", "Detalhe"], state.audit
      .filter((r) => matches(filters.audit, r.actor, r.action, r.ref, r.detail)).map((r) =>
        [`<span class="nowrap">${stamp(r.at)}</span>`, escape(r.actor), escape(r.action), escape(r.ref), escape(r.detail || "—")]));
  }
  function auditPage() {
    return heading("Auditoria", "Acompanhe alterações, aprovações, recebimentos e justificativas.", "", "Administração") +
      `<section class="panel"><div class="toolbar">${textField("audit", filters.audit, 'type="search" id="audit-search" aria-label="Buscar no histórico" placeholder="Buscar ação, registro ou responsável"')}</div>
      <div id="audit-rows">${auditTable()}</div></section>`;
  }
  const cashField = (name, amount) => textField(name, inputMoney(amount), 'inputmode="decimal" required maxlength="12"');
  function settingsPage() {
    const s = state.settings;
    return heading("Parâmetros de compra", "Defina limites, exigências e centros de custo da simulação.", "", "Administração") +
      (!canBuy() ? notice("Selecione o perfil Compras para alterar os parâmetros.", "warn") : "") +
      `<section class="panel">${panelHead("Regras operacionais", "As regras são avaliadas quando um rascunho é enviado.")}
      <div class="panel-body"><form data-form="settings"><fieldset ${!canBuy() ? "disabled" : ""}>
      <div class="form-grid three">
        ${field("Pedido mínimo (R$)", cashField("minOrder", s.minOrder))}
        ${field("Alçada da gerência a partir de (R$)", cashField("approval1", s.approval1))}
        ${field("Alçada da diretoria a partir de (R$)", cashField("approval2", s.approval2), "Exige gerência antes da diretoria.")}
        ${field("Desconto máximo por item (%)", cashField("maxDiscount", s.maxDiscount))}
        ${field("Exigir cotações a partir de (R$)", cashField("quoteFrom", s.quoteFrom))}
        ${field("Cotações distintas mínimas", textField("minQuotes", s.minQuotes, 'type="number" min="1" max="5" required'))}
        ${field("Taxa simulada sobre itens (%)", cashField("tax", s.tax), "Aplicada após desconto. Frete fora da base.")}
        ${field("Condição de pagamento padrão", select("payment", E.TERMS.map((t) => [t, t]), s.payment))}
        ${field("Centros de custo", `<textarea name="centers" rows="4">${escape(s.centers.join("\n"))}</textarea>`, "Um centro por linha.", true)}
      </div>
      <div class="form-section form-grid">
        <label class="check"><input type="checkbox" name="requireCenter" ${s.requireCenter ? "checked" : ""}>Tornar centro de custo obrigatório</label>
        <label class="check"><input type="checkbox" name="allowOverBudget" ${s.allowOverBudget ? "checked" : ""}>Permitir exceção de orçamento com duas aprovações</label>
      </div></fieldset>
      <div class="form-error" hidden role="alert" tabindex="-1"></div>
      ${canBuy() ? '<div class="form-actions"><button class="btn primary" type="submit">Salvar parâmetros</button></div>' : ""}</form></div></section>
      <section class="panel separated">${panelHead("Backup e dados de demonstração", "Exporte os dados para transportar a simulação para outro navegador.")}
        <div class="panel-body actions">${button("backup-export", "Baixar backup JSON", "", "download")}
        ${canBuy() ? button("backup-import", "Restaurar backup") + button("reset", "Restaurar demonstração", "danger") : ""}</div></section>`;
  }
  function render() {
    shell();
    const warning = loadIssue ? notice(loadIssue, "warn") : !storage ? notice("Armazenamento do navegador indisponível. Exporte um backup antes de fechar.", "warn") : "";
    const renderPage = { home: dashboard, orders: ordersPage, stock: stockPage, reports: reportsPage, audit: auditPage, settings: settingsPage };
    $("#content").innerHTML = warning + (catalog[view] ? catalogPage(view) : renderPage[view]());
  }
  const dialog = $("#dialog");
  function openDialog(title, sub, body, large = false) {
    if (!dialog.open) priorFocus = document.activeElement;
    dialog.classList.toggle("large", large);
    $("#dialog-inner").innerHTML = `<header class="dialog-head"><div><h2 id="dialog-title" tabindex="-1">${escape(title)}</h2>
      ${sub ? `<p class="subtitle">${escape(sub)}</p>` : ""}</div>
      ${button("dialog-close", "", "icon-btn", "close", 'aria-label="Fechar janela"')}</header><div class="dialog-body">${body}</div>`;
    if (!dialog.open) dialog.showModal();
    $("#dialog-title").focus();
    dialog.scrollTop = 0;
  }
  function closeDialog() { if (dialog.open) dialog.close(); }
  dialog.addEventListener("close", () => {
    if (priorFocus?.isConnected) priorFocus.focus();
    else $("#content").focus();
  });
  const formError = '<div class="form-error" role="alert" tabindex="-1" hidden></div>';
  function showError(form, error) {
    const node = $(".form-error", form);
    node.textContent = error.message || "Não foi possível concluir a ação.";
    node.hidden = false;
    node.focus();
  }
  function openRecord(kind, id) {
    if (!canBuy() || !catalog[kind]) return;
    const row = id ? lookup(kind, id) : {};
    if (!row) return;
    const info = catalog[kind];
    let details = "";
    if (kind === "clients") details = field("Segmento", textField("segment", row.segment, 'maxlength="80"')) +
      field("Orçamento mensal (R$)", cashField("budget", row.budget ?? 0), "Zero indica orçamento sem teto.");
    if (kind === "categories") details = field("Alçada adicional", select("level", [["0", "Regra padrão"], ["1", "Gerência"], ["2", "Gerência e diretoria"]], String(row.level ?? 0))) +
      field("Descrição", `<textarea name="description" maxlength="240">${escape(row.description)}</textarea>`, "", true);
    if (kind === "sellers") details = field("Equipe", textField("team", row.team, 'maxlength="80"'));
    if (kind === "suppliers") details = field("Contato", textField("contact", row.contact, 'maxlength="100"')) +
      field("Prazo padrão (dias)", textField("lead", row.lead ?? 5, 'type="number" min="0" max="365" required'));
    if (kind === "products") details = field("SKU", textField("sku", row.sku, 'required maxlength="36"')) +
      field("Categoria", select("categoryId", state.categories.filter((c) => c.active || c.id === row.categoryId).map((c) => [c.id, c.name]), row.categoryId, "Selecione")) +
      field("Custo unitário (R$)", cashField("price", row.price ?? 0)) +
      field("Tipo", select("type", [["stock", "Estocável"], ["service", "Serviço"]], row.type ?? "stock")) +
      field("Estoque mínimo", textField("minStock", row.minStock ?? 0, 'type="number" min="0" max="1000000" required'), "Somente para itens estocáveis.");
    const email = ["clients", "suppliers", "sellers"].includes(kind) ? field("E-mail", textField("email", row.email, 'type="email" maxlength="160"')) : "";
    openDialog((id ? "Editar " : "Cadastrar ") + info.one, info.info,
      `<form data-form="record" data-kind="${kind}" data-id="${id ?? ""}"><div class="form-grid">
      ${field("Nome", textField("name", row.name, 'required maxlength="120"'))}${email}${details}
      <label class="check"><input type="checkbox" name="active" ${row.active !== false ? "checked" : ""}>Cadastro ativo</label></div>
      ${formError}<div class="form-actions">${button("dialog-close", "Voltar")}<button class="btn primary" type="submit">Salvar cadastro</button></div></form>`);
  }
  const activeOptions = (kind, current = "") => state[kind].filter((r) => r.active || r.id === current).map((r) => [r.id, r.name]);
  function lineHtml(line = {}) {
    const products = state.products.filter((p) => (p.active && lookup("categories", p.categoryId)?.active) || p.id === line.productId);
    return `<div class="line-grid" data-line>
      <label class="field line-product">Produto${select("product", products.map((p) => [p.id, `${p.sku} · ${p.name}`]), line.productId ?? "", "Selecione")}</label>
      ${field("Qtd.", textField("qty", line.qty ?? 1, 'type="number" min="1" max="100000" required'))}
      ${field("Custo (R$)", cashField("price", line.price ?? 0))}
      ${field("Desconto %", cashField("discount", line.discount ?? 0))}
      <output class="line-amount" data-line-total aria-label="Total do item">R$ 0,00</output>
      ${button("remove-line", "", "icon-btn", "close", 'aria-label="Remover item"')}
    </div>`;
  }
  function openOrder(id) {
    if (!canBuy()) return;
    const order = id ? lookup("orders", id) : null;
    if (id && (!order || order.status !== "draft")) return;
    const missing = [["clients", "cliente"], ["sellers", "vendedor"], ["suppliers", "fornecedor"], ["products", "produto"]]
      .filter(([k]) => !state[k].some((r) => r.active)).map(([, label]) => label);
    if (missing.length) {
      openDialog("Cadastros necessários", "Cadastre os vínculos antes de criar um pedido.",
        notice("Faltam registros ativos de " + missing.join(", ") + ".", "warn"));
      return;
    }
    const when = order?.date ?? E.today();
    openDialog(id ? "Editar " + id : "Novo pedido de compra", "Confira os itens e salve o rascunho para validar as regras.",
      `<form data-form="order" data-id="${id ?? ""}">
      <div class="form-grid three">
      ${field("Cliente", select("clientId", activeOptions("clients", order?.clientId), order?.clientId, "Selecione"))}
      ${field("Fornecedor", select("supplierId", activeOptions("suppliers", order?.supplierId), order?.supplierId, "Selecione"))}
      ${field("Vendedor responsável", select("sellerId", activeOptions("sellers", order?.sellerId), order?.sellerId, "Selecione"))}
      ${field("Data do pedido", textField("date", when, 'type="date" required'))}
      ${field("Entrega prevista", textField("due", order?.due ?? dateOffset(when, 7), 'type="date" required'))}
      ${field("Centro de custo", select("center", [...new Set([...state.settings.centers, ...(order?.center ? [order.center] : [])])].map((c) => [c, c]), order?.center, "Selecione"))}
      ${field("Condição de pagamento", select("payment", E.TERMS.map((t) => [t, t]), order?.payment ?? state.settings.payment))}
      ${field("Frete (R$)", cashField("freight", order?.freight ?? 0))}
      </div>
      <div class="form-section"><h3>Itens do pedido</h3><div id="lines">${order ? order.lines.map(lineHtml).join("") : lineHtml()}</div>
      ${button("add-line", "Adicionar item", "small", "plus")}
      <div id="live-total" class="order-summary" aria-live="polite"></div></div>
      <div class="form-section form-grid">
      ${field("Cotações", `<textarea name="quotes" rows="3" maxlength="600" placeholder="Fornecedor alternativo | 12500,00">${escape(order?.quotes.map((q) => q.name + " | " + inputMoney(q.price)).join("\n") ?? "")}</textarea>`,
        "Uma cotação por linha no formato referência | valor.")}
      ${field("Observações", `<textarea name="notes" rows="3" maxlength="700">${escape(order?.notes)}</textarea>`)}
      </div>${formError}<div class="form-actions">${button("dialog-close", "Voltar")}<button class="btn primary" type="submit">Salvar rascunho</button></div>
      </form>`, true);
    updateTotals();
  }
  const lineValues = (node) => ({
    productId: $('[name="product"]', node).value, qty: Number($('[name="qty"]', node).value),
    price: cents($('[name="price"]', node).value), discount: cents($('[name="discount"]', node).value)
  });
  function updateTotals() {
    const form = $('form[data-form="order"]', dialog);
    if (!form) return;
    const nodes = $$("[data-line]", form);
    const lines = nodes.map(lineValues);
    const valid = lines.every((line) => Number.isSafeInteger(line.qty) && line.qty >= 1 && line.qty <= 100000 &&
      Number.isSafeInteger(line.price) && line.price >= 0 && line.price <= 1000000000 &&
      Number.isSafeInteger(line.discount) && line.discount >= 0 && line.discount <= 10000) &&
      lines.reduce((sum, line) => sum + line.qty * line.price, 0) <= 1000000000;
    const freight = cents(valueOf(form, "freight"));
    const tax = state.settings.tax;
    nodes.forEach((node, index) => {
      $("[data-line-total]", node).textContent = valid ? money(E.lineTotals(lines[index], tax).total) : "—";
    });
    $("#live-total").innerHTML = !valid || !Number.isSafeInteger(freight) ? "Revise os valores e as quantidades dos itens." : (() => {
      const sum = E.totals({ lines, tax, freight });
      return `<span>Itens ${money(sum.gross)}</span><span>Desconto ${money(sum.discount)}</span>
        <span>Taxa ${money(sum.tax)}</span><span>Frete ${money(sum.freight)}</span><strong>Total ${money(sum.total)}</strong>`;
    })();
  }
  function quoteValues(raw) {
    return raw.split(/\r?\n/).map((line) => line.trim()).filter(Boolean).map((line) => {
      const parts = line.split("|");
      if (parts.length !== 2) throw new Error("Use referência | valor em cada linha de cotação.");
      return { name: parts[0].trim(), price: cents(parts[1]) };
    });
  }
  function orderDetail(id) {
    const o = lookup("orders", id);
    if (!o) return;
    const role = currentRole();
    let assessment = null;
    if (o.status === "draft") {
      try { assessment = E.review(state, o); }
      catch (error) { assessment = { errors: [error.message], reasons: [], route: [] }; }
    }
    const tax = assessment?.order?.tax ?? o.tax;
    const t = E.totals({ ...o, tax });
    const info = [["Cliente", o.clientName], ["Fornecedor", o.supplierName], ["Vendedor", o.sellerName],
      ["Centro de custo", o.center || "—"], ["Data do pedido", date(o.date)], ["Entrega prevista", date(o.due)],
      ["Pagamento", o.payment], ["Solicitante", E.ACTORS[o.requester].name], ["Taxa sobre os itens", pct(tax)]];
    const route = assessment?.route ?? o.route;
    const nextRole = o.status === "review" ? o.route[o.approvals.length] : "";
    const tags = route.map((name, i) => badge(o.approvals[i] ? "active" : "review", name + (o.approvals[i] ? " · aprovado" : ""))).join("");
    const reasons = assessment?.reasons ?? o.reasons;
    const controls = [];
    if (canBuy()) {
      if (o.status === "draft") {
        controls.push(button("edit-order", "Editar rascunho", "", "pencil", actionOrder(id)),
          button("transition", "Enviar pedido", "primary", "arrow", actionOrder(id) + ' data-step="submit"' +
            (assessment.errors.length ? " disabled" : "")));
      }
      if (o.status === "approved") controls.push(button("transition", "Emitir pedido", "primary", "arrow", actionOrder(id) + ' data-step="issue"'));
      if (o.status === "rejected") controls.push(button("transition", "Reabrir rascunho", "primary", "pencil", actionOrder(id) + ' data-step="reopen"'));
      if (["draft", "review", "approved", "issued", "rejected"].includes(o.status))
        controls.push(button("explain-action", "Cancelar pedido", "danger", "", actionOrder(id) + ' data-step="cancel"'));
    }
    if (role === nextRole) controls.push(button("transition", "Aprovar pedido", "primary", "check", actionOrder(id) + ' data-step="approve"'),
      button("explain-action", "Reprovar pedido", "danger", "", actionOrder(id) + ' data-step="reject"'));
    if (role === "Estoque" && ["issued", "partial"].includes(o.status))
      controls.push(button("receive", "Registrar recebimento", "primary", "truck", actionOrder(id)));
    controls.push(button("print", "Imprimir", "", "order"));
    const history = state.audit.filter((r) => r.ref === id);
    openDialog("Pedido " + id, o.clientName + " · " + E.STATUS[o.status],
      `<div class="actions">${badge(o.status)}${datedOpen(o) ? badge("low", "Entrega em atraso") : ""}</div>
      <div class="form-section"><dl class="details">${info.map(([name, v]) => `<div><dt>${name}</dt><dd>${escape(v)}</dd></div>`).join("")}</dl></div>
      ${o.notes ? `<p class="form-section"><strong>Observações</strong><br>${escape(o.notes)}</p>` : ""}
      <div class="form-section"><h3>Itens e recebimentos</h3>
      ${table(["Produto", "Qtd.", "Recebida", "R$ Unitário", "Desconto", "R$ Total do item"], o.lines.map((l) =>
        [`<strong>${escape(l.name)}</strong><br><small class="muted">${escape(l.sku)}</small>`, units(l.qty), units(l.received),
          amount(l.price), pct(l.discount), amount(E.lineTotals(l, tax).total)]))}
      <div class="order-summary"><span>Itens ${money(t.gross)}</span><span>Desconto ${money(t.discount)}</span>
        <span>Taxa ${money(t.tax)}</span><span>Frete ${money(t.freight)}</span><strong>Total ${money(t.total)}</strong></div></div>
      <div class="form-section"><h3>Validação e alçadas</h3>
      ${assessment?.errors.length ? notice(assessment.errors.join(" "), "error") : ""}
      ${assessment?.budget ? `<p class="hint">Orçamento mensal ${money(assessment.budget)} · já comprometido ${money(assessment.committed)}.</p>` : ""}
      ${nextRole ? `<p>Próxima aprovação <strong>${nextRole}</strong>. Selecione o perfil correspondente no topo da página.</p>` : ""}
      ${tags ? `<div class="status-steps">${tags}</div>` : `<p class="hint">${o.status === "draft" ? "Nenhuma alçada adicional calculada para este rascunho." : "Sem alçadas manuais registradas."}</p>`}
      ${reasons.length ? `<ul class="rule-list">${reasons.map((r) => `<li>${escape(r)}</li>`).join("")}</ul>` : ""}
      <p class="hint separated">${o.quotes.length} cotação(ões) registrada(s)${o.quotes.length ? " · " + o.quotes.map((q) => escape(q.name) + " " + money(q.price)).join(" · ") : ""}</p>
      </div><div class="form-section"><h3>Histórico do pedido</h3>
      ${table(["Data", "Responsável", "Ação", "Detalhe"], history.map((r) => [stamp(r.at), escape(r.actor), escape(r.action), escape(r.detail || "—")]))}
      </div><div class="form-actions actions">${controls.join("")}</div>`, true);
  }
  function explanation(id, action) {
    const label = action === "reject" ? "Reprovar pedido" : "Cancelar pedido";
    openDialog(label, id + " · A justificativa fica registrada na auditoria.",
      `<form data-form="explain" data-id="${id}" data-step="${action}">
       ${field("Justificativa", '<textarea name="note" maxlength="400" required></textarea>')}${formError}
       <div class="form-actions">${button("order-detail", "Voltar", "", "", actionOrder(id))}<button class="btn danger" type="submit">${label}</button></div></form>`);
  }
  function receiveOrder(id) {
    const o = lookup("orders", id);
    if (!o) return;
    openDialog("Registrar recebimento", id + " · Quantidades pendentes por item",
      `<form data-form="receive" data-id="${id}">
       ${table(["Item", "Pedido", "Pendente", "Receber agora"], o.lines.map((l, i) =>
         [escape(l.name), l.qty, l.qty - l.received, textField("qty-" + i, 0,
           `type="number" min="0" max="${l.qty - l.received}" required aria-label="Receber ${escape(l.name)}"`)]))}
       <div class="form-section">${field("Documento ou referência", textField("note", "", 'required maxlength="150"'), "Exemplo: nota fictícia, remessa ou termo de aceite.")}</div>
       ${formError}<div class="form-actions">${button("order-detail", "Voltar", "", "", actionOrder(id))}
         <button class="btn primary" type="submit">Confirmar recebimento</button></div></form>`);
  }
  function adjust(id) {
    const p = lookup("products", id);
    if (!p) return;
    openDialog("Ajuste de estoque", p.name + " · Saldo atual " + units(E.stock(state, id)),
      `<form data-form="adjust" data-id="${id}"><div class="form-grid">
      ${field("Quantidade do ajuste", textField("delta", "", 'type="number" min="-1000000" max="1000000" required'), "Positivo para entrada, negativo para saída.")}
      ${field("Justificativa", `<textarea name="note" required maxlength="400"></textarea>`, "", true)}</div>
      ${formError}<div class="form-actions">${button("dialog-close", "Voltar")}<button class="btn primary" type="submit">Registrar ajuste</button></div></form>`);
  }
  function searchResults(query) {
    const needle = query.trim();
    if (!needle) return '<p class="hint separated">Digite um nome, SKU ou código de pedido.</p>';
    const orders = state.orders.filter((o) => matches(needle, o.id, o.clientName, o.supplierName)).map((o) =>
      `<button type="button" class="search-result" data-action="order-detail" ${actionOrder(o.id)}><strong>${o.id}</strong> · ${escape(o.clientName)}<small>${E.STATUS[o.status]}</small></button>`);
    const records = Object.entries(catalog).flatMap(([k, label]) => state[k].filter((r) => matches(needle, r.name, r.sku, r.id))
      .map((r) => `<button type="button" class="search-result" data-action="search-record" data-kind="${k}" data-id="${r.id}">
        <strong>${escape(r.name)}</strong><small>${label.title} · ${escape(r.sku || r.id)}</small></button>`));
    return [...orders, ...records].slice(0, 20).join("") || '<p class="empty">Nenhum resultado encontrado.</p>';
  }
  function search() {
    openDialog("Busca global", "Encontre pedidos e registros dos cadastros.",
      field("Buscar", textField("globalSearch", "", 'id="global-search" type="search" placeholder="Ex.: Aurora Norte, EQ-010 ou PC-"')) +
      `<div id="search-results">${searchResults("")}</div>`);
    $("#global-search").focus();
  }
  function download(name, content, type) {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  function csvCell(value) {
    let raw = String(value ?? "");
    if (/^\s*[=+\-@]/.test(raw)) raw = "'" + raw;
    return '"' + raw.replaceAll('"', '""') + '"';
  }
  function exportCsv() {
    const rows = [["Pedido", "Cliente", "Fornecedor", "Vendedor", "Centro de custo", "Data", "Entrega", "Situação", "Total BRL"],
      ...reportRows().map((o) => [o.id, o.clientName, o.supplierName, o.sellerName, o.center, o.date, o.due, E.STATUS[o.status],
        inputMoney(E.totals(o).total).replace(".", ",")])];
    download("nexo-pedidos.csv", "\ufeff" + rows.map((r) => r.map(csvCell).join(";")).join("\r\n"), "text/csv;charset=utf-8");
    toast("Relatório CSV preparado.");
  }
  function openHelp() {
    openDialog("Como simular uma compra", "Use os perfis do topo para percorrer o fluxo.",
      '<ol class="rule-list"><li>Em Compras, abra <strong>Novo pedido</strong> e escolha cliente, fornecedor, vendedor e itens.</li>' +
      '<li>Salve o rascunho. O pedido mostra os bloqueios e as alçadas antes do envio.</li>' +
      '<li>Se houver aprovação, troque para Gerência e depois para Diretoria, quando exigida.</li>' +
      '<li>Volte a Compras para emitir. Em Estoque, abra o pedido emitido e registre a entrega parcial ou total.</li>' +
      '<li>Confira o saldo, a auditoria e os relatórios. Em Parâmetros, exporte o backup da simulação.</li></ol>');
  }
  function confirmRestore(kind) {
    openDialog(kind === "reset" ? "Restaurar demonstração" : "Restaurar backup", "Esta ação substitui a base atual do navegador.",
      '<p>Exporte um backup antes de continuar se quiser guardar a base atual.</p>' +
      `<div class="form-actions">${button("dialog-close", "Voltar")}${button("do-restore", "Confirmar substituição", "danger", "", 'data-mode="' + kind + '"')}</div>`);
  }
  function doTransition(id, action, note) {
    commit((s) => E.transition(s, id, action, actor, note));
    render();
    orderDetail(id);
    toast("Situação do pedido atualizada.");
  }
  document.addEventListener("click", (event) => {
    const b = event.target.closest("button");
    if (!b) return;
    if (b.dataset.go) { go(b.dataset.go); return; }
    const { action, id, kind, step, mode } = b.dataset;
    if (!action) return;
    try {
      if (action === "menu") {
        const expanded = $("#sidebar").classList.toggle("open");
        $('#topbar [data-action="menu"]').setAttribute("aria-expanded", String(expanded));
        $(expanded ? '#sidebar [data-action="menu"]' : '#topbar [data-action="menu"]').focus();
      }
      if (action === "dialog-close") closeDialog();
      if (action === "search") search();
      if (action === "help") openHelp();
      if (action === "new-record" || action === "edit-record") openRecord(kind, id);
      if (action === "new-order" || action === "edit-order") openOrder(id);
      if (action === "order-detail") orderDetail(id);
      if (action === "search-record") { filters.list[kind] = lookup(kind, id)?.name ?? ""; go(kind); }
      if (action === "add-line" && $$("[data-line]", dialog).length < 50) {
        $("#lines").insertAdjacentHTML("beforeend", lineHtml());
        $('[name="product"]', $("#lines").lastElementChild).focus();
        updateTotals();
      }
      if (action === "remove-line") {
        if ($$("[data-line]", dialog).length > 1) b.closest("[data-line]").remove();
        else $("#lines").innerHTML = lineHtml();
        updateTotals();
        $('[data-action="add-line"]', dialog).focus();
      }
      if (action === "transition") doTransition(id, step);
      if (action === "explain-action") explanation(id, step);
      if (action === "receive") receiveOrder(id);
      if (action === "adjust") adjust(id);
      if (action === "print") window.print();
      if (action === "export-csv") exportCsv();
      if (action === "backup-export") download("nexo-backup.json", JSON.stringify(state, null, 2), "application/json");
      if (action === "backup-import" && canBuy()) { $("#backup-file").value = ""; $("#backup-file").click(); }
      if (action === "reset" && canBuy()) confirmRestore("reset");
      if (action === "do-restore" && canBuy()) {
        const next = mode === "reset" ? E.seed() : pendingBackup;
        if (!next) throw new Error("Selecione um backup válido.");
        replaceState(next); pendingBackup = null;
        closeDialog(); render(); toast("Base restaurada.");
      }
    } catch (error) {
      openDialog("Ação interrompida", "Confira os requisitos e tente novamente.", notice(error.message, "error") +
        (id && lookup("orders", id) ? button("order-detail", "Voltar ao pedido", "", "", actionOrder(id)) : ""));
    }
  });
  document.addEventListener("submit", (event) => {
    const form = event.target;
    const { form: type, kind, id, step } = form.dataset;
    if (!type) return;
    event.preventDefault();
    const val = (name) => valueOf(form, name);
    try {
      if (type === "record") {
        commit((s) => E.saveRecord(s, kind, { name: val("name"), active: flag(form, "active"), email: val("email"),
          budget: cents(val("budget")), segment: val("segment"), team: val("team"), lead: Number(val("lead")), contact: val("contact"),
          description: val("description"), level: Number(val("level")), sku: val("sku"), categoryId: val("categoryId"),
          price: cents(val("price")), type: val("type"), minStock: Number(val("minStock")) }, actor, id));
        closeDialog(); render(); toast("Cadastro salvo.");
      }
      if (type === "order") {
        const order = commit((s) => E.saveOrder(s, { clientId: val("clientId"), supplierId: val("supplierId"), sellerId: val("sellerId"),
          date: val("date"), due: val("due"), center: val("center"), payment: val("payment"), freight: cents(val("freight")),
          notes: val("notes"), quotes: quoteValues(val("quotes")), lines: $$("[data-line]", form).map(lineValues) }, actor, id));
        render(); orderDetail(order.id); toast("Rascunho salvo.");
      }
      if (type === "explain") doTransition(id, step, val("note"));
      if (type === "receive") {
        const o = lookup("orders", id);
        commit((s) => E.receive(s, id, o.lines.map((_, i) => Number(val("qty-" + i))), val("note"), actor));
        render(); orderDetail(id); toast("Recebimento registrado.");
      }
      if (type === "adjust") {
        commit((s) => E.adjustment(s, id, Number(val("delta")), val("note"), actor));
        closeDialog(); render(); toast("Ajuste registrado.");
      }
      if (type === "settings") {
        const settings = Object.fromEntries(["minOrder", "approval1", "approval2", "maxDiscount", "quoteFrom", "tax"].map((k) => [k, cents(val(k))]));
        commit((s) => E.saveSettings(s, { ...settings, minQuotes: Number(val("minQuotes")), payment: val("payment"),
          requireCenter: flag(form, "requireCenter"), allowOverBudget: flag(form, "allowOverBudget"),
          centers: val("centers").split(/\r?\n/).map((line) => line.trim()).filter(Boolean) }, actor));
        render(); toast("Parâmetros atualizados.");
      }
    } catch (error) { showError(form, error); }
  });
  document.addEventListener("input", ({ target }) => {
    if (target.id === "order-search") { filters.orders = target.value; $("#order-rows").innerHTML = ordersTable(filteredOrders()); }
    if (target.id === "catalog-search") { filters.list[view] = target.value; $("#catalog-rows").innerHTML = catalogTable(view); }
    if (target.id === "inventory-search") { filters.inventory = target.value; $("#inventory-rows").innerHTML = inventoryTable(); }
    if (target.id === "audit-search") { filters.audit = target.value; $("#audit-rows").innerHTML = auditTable(); }
    if (target.id === "global-search") $("#search-results").innerHTML = searchResults(target.value);
    if (target.closest('form[data-form="order"]')) updateTotals();
  });
  document.addEventListener("change", async ({ target }) => {
    if (target.id === "actor" && E.ACTORS[target.value]) {
      actor = target.value; closeDialog(); render(); $("#actor").focus(); toast("Perfil de simulação: " + currentRole());
    }
    if (target.id === "home-period") { filters.home = target.value; render(); $("#home-period").focus(); }
    if (target.id === "order-status" || target.id === "order-client") {
      filters[target.id === "order-status" ? "orderStatus" : "orderClient"] = target.value;
      $("#order-rows").innerHTML = ordersTable(filteredOrders());
    }
    if (target.id === "report-month" || target.id === "report-client") {
      filters[target.id === "report-month" ? "month" : "reportClient"] = target.value;
      render(); $("#" + target.id).focus();
    }
    if (target.name === "product" && target.closest("[data-line]")) {
      const p = lookup("products", target.value);
      $('[name="price"]', target.closest("[data-line]")).value = inputMoney(p?.price ?? 0);
      updateTotals();
    }
    if (target.name === "supplierId" && target.closest('form[data-form="order"]')) {
      const form = target.form, supplier = lookup("suppliers", target.value);
      if (!form.dataset.id && supplier) form.elements.due.value = dateOffset(form.elements.date.value, supplier.lead);
    }
    if (target.id === "backup-file" && target.files[0] && canBuy()) {
      try {
        if (target.files[0].size > 6000000) throw new Error("O arquivo de backup excede 6 MB.");
        pendingBackup = E.importBackup(JSON.parse(await target.files[0].text()));
        confirmRestore("backup");
      } catch (error) { pendingBackup = null; openDialog("Backup inválido", "A base atual foi preservada.", notice(error.message, "error")); }
    }
  });
  window.addEventListener("storage", (event) => {
    if (event.key !== key || !event.newValue) return;
    try { state = E.importBackup(JSON.parse(event.newValue)); render(); }
    catch { toast("A alteração em outra aba não pôde ser carregada."); }
  });
  window.addEventListener("popstate", () => { view = hashPage(); closeDialog(); render(); });
  document.addEventListener("keydown", (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); search(); }
    if (event.key === "Escape" && $("#sidebar").classList.contains("open")) {
      $("#sidebar").classList.remove("open");
      const trigger = $('#topbar [data-action="menu"]');
      trigger.setAttribute("aria-expanded", "false");
      trigger.focus();
    }
  });
  view = hashPage();
  render();
})();
